export const database = [
  { name: { en: "Peter", ru: "Петр" }, image: "./images/peter.jpg" },
  { name: { en: "Roma", ru: "Рома" }, image: "./images/roma.jpg" },
  { name: { en: "Izabella", ru: "Изабелла" }, image: "./images/izabella.jpg" },
];
